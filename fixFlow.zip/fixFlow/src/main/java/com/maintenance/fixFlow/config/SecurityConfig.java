package com.maintenance.fixFlow.config;

import com.maintenance.fixFlow.security.CustomAccessDeniedHandler;
import com.maintenance.fixFlow.security.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final CustomAccessDeniedHandler customAccessDeniedHandler;

    public SecurityConfig(
            JwtAuthenticationFilter jwtAuthenticationFilter,
            CustomAccessDeniedHandler customAccessDeniedHandler) {

        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
        this.customAccessDeniedHandler = customAccessDeniedHandler;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration configuration) throws Exception {

        return configuration.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http) throws Exception {

                http.csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth ->auth
                                .requestMatchers(HttpMethod.POST, "/api/users").permitAll()
                                .requestMatchers(HttpMethod.POST, "/auth/login").permitAll()

                                // Property
                                .requestMatchers(HttpMethod.GET, "/api/property/**")
                                .hasAnyRole("TENANT", "VENDOR", "MANAGER")

                                .requestMatchers(HttpMethod.POST, "/api/property/**")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.PUT, "/api/property/**")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.DELETE, "/api/property/**")
                                .hasRole("MANAGER")

                                // Unit
                                .requestMatchers(HttpMethod.GET, "/api/unit/**")
                                .hasAnyRole("TENANT", "VENDOR", "MANAGER")

                                .requestMatchers(HttpMethod.POST, "/api/unit")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.POST, "/api/unit/**")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.PUT, "/api/unit/**")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.DELETE, "/api/unit/**")
                                .hasRole("MANAGER")

                                // Assignment
                                .requestMatchers(HttpMethod.GET, "/api/assignment/getAll")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.POST, "/api/assignment/**")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.DELETE, "/api/assignment/**")
                                .hasRole("MANAGER")

                                //Maintenance Request
                                .requestMatchers(HttpMethod.GET,
                                        "/api/maintenanceRequest/getAll"
                                )
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.POST, "/api/maintenanceRequest/admin")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.PUT, "/api/maintenanceRequest/admin/**")
                                .hasRole("MANAGER")

                                //Attachment
                                .requestMatchers(HttpMethod.GET, "/api/attachment/getAll")
                                .hasRole("MANAGER")

                                //Comment
                                .requestMatchers(HttpMethod.GET, "/api/comment/getAll")
                                .hasRole("MANAGER")

                                //workUpdate
                                .requestMatchers(HttpMethod.GET, "/api/workUpdate/getAll")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.POST, "/api/workUpdate")
                                .hasAnyRole("MANAGER", "VENDOR")

                                //Notification
                                .requestMatchers(HttpMethod.GET, "/api/notification/getAll")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.POST, "/api/notification/**")
                                .hasRole("MANAGER")

                                //Rating
                                .requestMatchers(HttpMethod.GET, "/api/rating/getAll")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.POST, "/api/rating")
                                .hasRole("TENANT")

                                //User
                                .requestMatchers(HttpMethod.GET, "/api/users/getAll")
                                .hasRole("MANAGER")

                                .requestMatchers(HttpMethod.PUT, "/api/users/admin/**")
                                .hasRole("MANAGER")

                                // other all requests requires login
                                .anyRequest().authenticated()
                        )

                        .exceptionHandling(exception -> exception
                                .accessDeniedHandler(customAccessDeniedHandler)
                        )

                        .addFilterBefore(
                                jwtAuthenticationFilter,
                                UsernamePasswordAuthenticationFilter.class
                        );


        return http.build();
    }
}